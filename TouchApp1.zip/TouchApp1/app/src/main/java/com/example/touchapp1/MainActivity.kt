package com.example.touchapp1

import android.os.Bundle
import android.view.MotionEvent
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var tvCoordinates: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvCoordinates = findViewById(R.id.tvCoordinates)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                tvCoordinates.text = "Натиснато: X = %.1f, Y = %.1f".format(x, y)
            }
            MotionEvent.ACTION_MOVE -> {
                tvCoordinates.text = "Движение: X = %.1f, Y = %.1f".format(x, y)
            }
            MotionEvent.ACTION_UP -> {
                tvCoordinates.text = "Пуснато: X = %.1f, Y = %.1f".format(x, y)
            }
        }

        return true
    }
}